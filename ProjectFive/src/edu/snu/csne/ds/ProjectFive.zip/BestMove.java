package edu.snu.csne.ds;

public interface BestMove
{
	public int getBestMove( ArrayToeBoard board );
}
