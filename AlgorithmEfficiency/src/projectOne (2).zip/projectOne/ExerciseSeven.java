package projectOne;

public class ExerciseSeven
{
	// create bag
	BagADT< String > bag = new BagADT< String >();
	
}
