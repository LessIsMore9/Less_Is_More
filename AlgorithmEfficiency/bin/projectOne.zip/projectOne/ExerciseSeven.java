package projectOne;

public class ExerciseSeven {

}
